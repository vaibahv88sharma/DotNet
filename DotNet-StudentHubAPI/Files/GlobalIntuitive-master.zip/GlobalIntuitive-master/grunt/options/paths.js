module.exports = function(grunt){
	
	grunt.config('s', 'src/'); // The source directory
	grunt.config('d', 'dist/'); // The distributable directory, where built files will end up
	grunt.config('t', 'test/'); // The test directory, for unit test files/specs

};