module.exports = function(grunt){
	grunt.config('filename', 'contact-data-services'); // Construct a filename from package vars
};